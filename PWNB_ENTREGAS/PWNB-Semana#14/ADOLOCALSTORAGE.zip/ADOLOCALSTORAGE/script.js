const clientes = [];
const validarCEP = (CEP) => {
    const regexCEP = /^\d{5}-\d{3}$/;
    return regexCEP.test(CEP);
};
const incluirCliente = () => {
    const nome = document.getElementById('nome').value;
    const sobrenome = document.getElementById('sobrenome').value
    const UF = document.getElementById('UF').value;
    const dataNascimento = document.getElementById('dtnasc').value
    const CEP = document.getElementById('CEP').value
    const endereco = document.getElementById('endereco').value
    const numero = document.getElementById('num').value
    if (!nome || !sobrenome || !UF || !dataNascimento || !endereco || !CEP || !numero || !validarCEP(CEP)) {
        alert('Preencha todos os campos corretamente.');
        return
    }
    const novoCliente = {
        nome,
        sobrenome,
        UF,
        dataNascimento,
        CEP,
        endereco,
        numero
    }
    const dadosLocalStorage = localStorage.getItem('clientes')
    let clientes
    if (dadosLocalStorage) {
        clientes = JSON.parse(dadosLocalStorage)
    } else {
        clientes = []
    }
    const clienteExistente = clientes.find(cliente => cliente.nome === novoCliente.nome && cliente.sobrenome === novoCliente.sobrenome)
    if (!clienteExistente) {
        clientes.push(novoCliente);
        localStorage.setItem('clientes', JSON.stringify(clientes))
        limparCampos()
        preencherTabela()
    } else {
        alert('Cliente já existe na lista.')
    }
};
const limparCampos = () => {
    document.getElementById('nome').value = ''
    document.getElementById('sobrenome').value = ''
    document.getElementById('UF').value = ''
    document.getElementById('dtnasc').value = ''
    document.getElementById('CEP').value = ''
    document.getElementById('endereco').value = ''
    document.getElementById('num').value = ''
};
