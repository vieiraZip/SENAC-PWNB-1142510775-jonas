const preencherTabela = () => {
    const tabela = document.querySelector('table')
    const dadosLocalStorage = localStorage.getItem('clientes')
    const clientes = JSON.parse(dadosLocalStorage)
    tabela.innerHTML = ''
    if (clientes && clientes.length > 0) {
        clientes.forEach(cliente => {
            const novaLinha = tabela.insertRow(-1)
            novaLinha.insertCell(0).textContent = cliente.nome + " " + cliente.sobrenome
            novaLinha.insertCell(1).textContent = cliente.dataNascimento
            novaLinha.insertCell(2).textContent = cliente.CEP
            const endereco = cliente.endereco ? cliente.endereco + " " + cliente.numero : "N/A"
            novaLinha.insertCell(3).textContent = endereco
            novaLinha.classList.add('cliente', cliente.length)
            novaLinha.addEventListener('click', () => {
                selecionarLinha(novaLinha)
            })
            novaLinha.insertCell(4).innerHTML = `<div class="btnexcluir"><button onclick="excluirLinha(${cliente.length})"><img src="lixeira.png" alt="some text" width=20 height=10></button></div>`
        })
    }
}
const excluirLinha = (clienteLength) => {
    const linhaParaExcluir = document.querySelector(`.${clienteLength}`)

    if (linhaParaExcluir) {
        const dadosLocalStorage = localStorage.getItem('clientes')
        const clientes = JSON.parse(dadosLocalStorage)
        const clienteIndex = clientes.findIndex(cliente => cliente.length === clienteLength)
        if (clienteIndex !== -1) {
            clientes.splice(clienteIndex, 1)
            localStorage.setItem('clientes', JSON.stringify(clientes))
        } else {
            console.error('Cliente não encontrado para exclusão.')
        }
        linhaParaExcluir.remove()
    } else {
        console.error('Linha não encontrada para exclusão.')
    }
}
const selecionarLinha = (linha) => {
    const linhas = document.querySelectorAll('table tr')
    linhas.forEach(l => l.classList.remove('selecionada'))
    linha.classList.add('selecionada')
}
const excluirSelecionados = () => {
    const linhaSelecionada = document.querySelector('.selecionada')
    if (linhaSelecionada) {
        const clienteLength = linhaSelecionada.classList[1]
        excluirLinha(clienteLength)
    } else {
        console.error('Nenhuma linha selecionada.')
    }
}
const limparCampos = () => {
    document.getElementById('nome').value = ''
    document.getElementById('sobrenome').value = ''
    document.getElementById('UF').value = ''
    document.getElementById('dtnasc').value = ''
    document.getElementById('CEP').value = ''
    document.getElementById('endereco').value = ''
    document.getElementById('num').value = ''
}
window.onload = preencherTabela;
